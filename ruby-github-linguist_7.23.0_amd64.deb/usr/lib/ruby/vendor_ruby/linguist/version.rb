module Linguist
  VERSION = File.read(File.expand_path("../VERSION", __FILE__)).strip
end
